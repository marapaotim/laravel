<?php
/* Smarty version 3.1.32-dev-38, created on 2018-01-11 16:29:52
  from 'C:\xampp\htdocs\smarty\tpl\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32-dev-38',
  'unifunc' => 'content_5a5782f0dc6724_26866382',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3011cd924d4038d239fa717cda6d13ed5d651cbc' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\tpl\\login.tpl',
      1 => 1514904537,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:menu.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5a5782f0dc6724_26866382 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="container">
	<div class="row">
		<center><h3><u>Login Form</u></h3></center>
		<hr> 
		<div class="col-sm-6 col-md-4 col-md-offset-4 account-wall">
			<form method="post" id="signinform">
			  <div class="form-group">
			    <label for="exampleInputEmail1">Username</label>
			    <input type="text" class="form-control" id="username" placeholder="Username" required> 
			  </div>
			  <div class="form-group">
			    <label for="exampleInputPassword1">Password</label>
			    <input type="password" class="form-control" id="password" placeholder="Password" required>
			  </div> 
			  <input type="submit" id="submit" class="btn btn-lg btn-primary btn-block" value="SUBMIT">   
			  <br>
			  <label><input type="checkbox" value="remember-me"> Remember me</label>
                <a href="?action=signup" class="pull-right">Sign Up here </a>
			</form>
		</div>
	</div>
</div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
