<?php
/* Smarty version 3.1.32-dev-38, created on 2018-01-11 16:29:54
  from 'C:\xampp\htdocs\smarty\tpl\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32-dev-38',
  'unifunc' => 'content_5a5782f2b52d03_96301253',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c28a1c7e30212a11d7a50659d69dea2e1c646002' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\tpl\\footer.tpl',
      1 => 1514689684,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a5782f2b52d03_96301253 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="footer">
      <div class="container1">
        <p class="text-muted">Powered by Smarty Template</p>
      </div>
 </footer>
</body>
</html><?php }
}
