<?php
/* Smarty version 3.1.32-dev-38, created on 2018-01-11 16:29:54
  from 'C:\xampp\htdocs\smarty\tpl\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32-dev-38',
  'unifunc' => 'content_5a5782f2ac0f30_71556845',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd4ac89c22bf0ed60616ca473705739a99af2efbc' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty\\tpl\\index.tpl',
      1 => 1515304713,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:menu.tpl' => 1,
    'file:message_list.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5a5782f2ac0f30_71556845 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="container-fluid">
<center><h3><u>Welcome to Guestbook Application</u></h3></center>
<hr> 

      <div class="row">
        <div class="col-md-6 col-sm-6">
          <form method="post" id="myform"> 
            <div class="alert alert-success alert-dismissable" style="display:none;"></div>
            <div class="form-group">
              <label for="message">Name</label>
              <input type="text" name="fname" id="fname" class="form-control" placeholder="Full name" required>
            </div>  
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" name="email" class="form-control" id="email" placeholder="Email Address" required>
            </div>
            <div class="form-group">
              <label for="message">Message</label>
              <textarea name="message" class="form-control" id="message" placeholder="Message Us" rows="6" required></textarea>
            </div>    
            <input type="submit" id="submit" class="btn btn-primary" value="SAVE">  
          </form> 
        </div>
        <div class="col-md-6 col-sm-6">
          <div id="myTable">
            <?php $_smarty_tpl->_subTemplateRender("file:message_list.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
          </div>
        </div>    
      </div> 
  </div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
